#include "ftl.h"
#include "nand.h"
#include <assert.h>

struct ftl_stats stats;
void sim_init(void)
{
	stats.gc_cnt = 0;
	stats.nand_write = 0;
	stats.gc_write = 0;
	stats.host_write = 0;
	srand(100);

	ftl_open();
}

void show_info(void)
{
	printf("Bank: %d\n", N_BANKS);
	printf("Blocks / Bank: %d blocks\n", BLKS_PER_BANK);
	printf("Pages / Block: %d pages\n", PAGES_PER_BLK);
	printf("OP ratio: %d%%\n", OP_RATIO);
	printf("Physical Blocks: %d\n", N_BLOCKS);
	printf("User Blocks: %d\n", N_USER_BLOCKS);
	printf("OP Blocks: %d\n", N_OP_BLOCKS);
	printf("PPNs: %d\n", N_PPNS);
	printf("LPNs: %d\n", N_LPNS);

	printf("Workload: Random\n");
	printf("FTL: Greedy policy\n");
	
	printf("\n");
}

u32 get_lba()
{
	long lba;
	lba = rand() % (N_LPNS*SECTORS_PER_PAGE);
	return lba;
}

u32 get_data(u32 lpn)
{
	if (lpn % 0xF == 0x0) return 0x00;
	if (lpn % 0xF == 0x1) return 0x11;
	else if (lpn % 0xF == 0x2) return 0x22;
	else if (lpn % 0xF == 0x3) return 0x33;
	else if (lpn % 0xF == 0x4) return 0x44;
	else if (lpn % 0xF == 0x5) return 0x55;
	else if (lpn % 0xF == 0x6) return 0x66;
	else if (lpn % 0xF == 0x7) return 0x77;
	else if (lpn % 0xF == 0x8) return 0x88;
	else if (lpn % 0xF == 0x9) return 0x99;
	else if (lpn % 0xF == 0xa) return 0xaa;
	else if (lpn % 0xF == 0xb) return 0xbb;
	else if (lpn % 0xF == 0xc) return 0xcc;
	else if (lpn % 0xF == 0xd) return 0xdd;
	else if (lpn % 0xF == 0xe) return 0xee;
	else return 0xff;
}

void sim()
{
	u32 lba;
	u32 write_buffer[SECTORS_PER_PAGE*4];
	u32 read_buffer[SECTORS_PER_PAGE*4];
	int cnt = 0;
	int cmt = 0;
	int MAX_ITERATION = 30*N_BANKS*BLKS_PER_BANK*PAGES_PER_BLK;
	while (cnt < MAX_ITERATION)
	{
		lba = get_lba();
		
		int nsect = rand()%31 +1;
		if(lba + nsect >=(N_LPNS*SECTORS_PER_PAGE)){
			lba/=2;
		}
		memset(write_buffer, get_data(lba), nsect*sizeof(int));
		memset(read_buffer, 0, nsect*sizeof(int));

		ftl_write(lba,nsect, write_buffer);
		ftl_read(lba,nsect,read_buffer);
		cnt++;cmt++;
		if (memcmp(write_buffer, read_buffer, nsect*sizeof(int))) assert(0); 

		if (cmt == N_BANKS*BLKS_PER_BANK*PAGES_PER_BLK)
		{
			cmt = 0;
			printf("[Run %d] host write %d nand write %d gc write %d  GC# %d, WAF %.2f\n",
					(cnt/(N_BANKS*BLKS_PER_BANK*PAGES_PER_BLK)),stats.host_write,stats.nand_write*8,stats.gc_write*8,stats.gc_cnt,
					((double)(8*(stats.nand_write + stats.gc_write))/(double)stats.host_write));
		}

	}
}

void show_stat(void)
{
	printf("\nResults ------\n");
	printf("Host writes: %d\n", stats.host_write);
	printf("Nand writes: %d\n", stats.nand_write*8);
	printf("GC writes: %d\n", stats.gc_write*8);
	printf("Number of GCs: %d\n", stats.gc_cnt);
	printf("Valid pages per GC: %.2f pages\n", (double)stats.gc_write / (double)stats.gc_cnt);
	printf("WAF: %.2f\n", ((double)(8*(stats.nand_write+stats.gc_write))/(double)stats.host_write));
}

int main(void)
{
	sim_init();
	show_info();
	sim();
	show_stat();
	return 0;
}

